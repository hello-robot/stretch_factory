![](./images/banner.png)
# Overview

The Stretch Factory package provides Python tools for testing and calibration of the Hello Robot Stretch RE1. 

**These tools are provided for reference only and are intended to be used by qualified Hello Robot production engineers.** 

This package can be installed by:

```
pip2 install  hello-robot-stretch-factory
```

